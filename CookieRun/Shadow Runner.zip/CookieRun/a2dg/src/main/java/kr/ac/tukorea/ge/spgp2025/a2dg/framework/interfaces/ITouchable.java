package kr.ac.tukorea.ge.spgp2025.a2dg.framework.interfaces;

import android.view.MotionEvent;

public interface ITouchable {
    public boolean onTouchEvent(MotionEvent e);
}
