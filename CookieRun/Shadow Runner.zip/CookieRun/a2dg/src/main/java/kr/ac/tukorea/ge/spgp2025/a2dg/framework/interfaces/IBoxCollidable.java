package kr.ac.tukorea.ge.spgp2025.a2dg.framework.interfaces;

import android.graphics.RectF;

public interface IBoxCollidable {
    public RectF getCollisionRect();
}
